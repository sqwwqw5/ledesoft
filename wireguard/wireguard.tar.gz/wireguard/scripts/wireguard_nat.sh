#!/bin/sh

/koolshare/scripts/wireguard_config.sh > /tmp/upload/wireguard_log.txt &
